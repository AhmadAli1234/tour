<?php
namespace Modules\Api\Controllers;

class MediaController extends \Modules\Media\Admin\MediaController
{

}
