<?php
namespace Modules\Booking\Models;

use App\BaseModel;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use Modules\Car\Models\Car;
use Modules\Hotel\Models\Hotel;
use Modules\Location\Models\Location;
use Modules\Space\Models\Space;
use Modules\Tour\Models\Tour;

class Service extends BaseModel
{
    use SoftDeletes;
    public    $type          = 'service';
    public    $allowType     = [
        'hotel',
        'space',
        'tour',
        'car',
        'event',
        'flight',
    ];
    protected $table         = 'bc_services';
    protected $slugField     = 'slug';
    protected $slugFromField = 'title';
    protected $fillable      = [
        'title',
        'location_id',
        'category_id',
        'address',
        'map_lat',
        'map_lng',
        'is_featured',
        'star_rate',
        'price',
        'sale_price',
        'min_people',
        'max_people',
        'max_guests',
        'review_score',
        'min_day_before_booking',
        'min_day_stays',
        'locale',
        'object_id',
        'object_model',
        'status'
    ];

    public static function cloneService($model, $event)
    {
        try {
            if (!empty($model->type) and $model->type != 'service' and in_array($model->type, (new Service())->allowType)) {
                $service = self::where('object_model', $model->type)->where('object_id', $model->id)->first();
                if (empty($service)) {
                    $service = new Service();
                }
                if (is_default_lang()) {
                    $service->fill($model->attributes);
                    $service->object_id = $model->id;
                    $service->object_model = $model->type;
                    $service->save();
                } else {
                    $getRecordRoot = $model->getRecordRoot;
                    if (!empty($getRecordRoot)) {
                        $service = self::where('object_model', $getRecordRoot->type)->where('object_id', $getRecordRoot->id)->first();
                        if (empty($service)) {
                            $service = new Service();
                            $service->fill($getRecordRoot->attributes);
                            $service->object_id = $getRecordRoot->id;
                            $service->object_model = $getRecordRoot->type;
                            $service->save();
                        }
                        $serviceTranslation = new ServiceTranslation($model->attributes);
                        $service->Translations()->save($serviceTranslation);
                    }
                }
            }
        } catch (\Exception $e) {
        }
    }

    public static function deleteService($model)
    {
        try {
            if (!empty($model->type) and $model->type != 'service' and in_array($model->type, (new Service())->allowType)) {
                $service = self::where('object_model', $model->type)->where('object_id', $model->id)->first();
                if (!empty($service)) {
                    $a = $service->delete();
                }
            }
        } catch (\Exception $e) {
        }
    }

    public static function restoreService($model)
    {
        try {
            if (!empty($model->type) and $model->type != 'service' and in_array($model->type, (new Service())->allowType)) {
                $service = self::withTrashed()->where('object_model', $model->type)->where('object_id', $model->id)->first();
                if (!empty($service)) {
                    $service->restore();
                }
            }
        } catch (\Exception $e) {
        }
    }

    public static function search(Request $request)
    {
        $model_service = parent::query()->select("bc_services.*");
        $model_service->where("bc_services.status", "publish");
        if (!empty($location_id = $request->query('location_id'))) {
            $location = Location::query()->where('id', $location_id)->where("status", "publish")->first();
            if (!empty($location)) {
                $model_service->join('bc_locations', function ($join) use ($location) {
                    $join->on('bc_locations.id', '=', 'bc_services.location_id')->where('bc_locations._lft', '>=', $location->_lft)->where('bc_locations._rgt', '<=', $location->_rgt);
                });
            }
        }
        if (!empty($price_range = $request->query('price_range'))) {
            $pri_from = explode(";", $price_range)[0];
            $pri_to = explode(";", $price_range)[1];
            $raw_sql_min_max = "( (IFNULL(bc_services.sale_price,0) > 0 and bc_services.sale_price >= ? ) OR (IFNULL(bc_services.sale_price,0) <= 0 and bc_services.price >= ? ) ) 
                            AND ( (IFNULL(bc_services.sale_price,0) > 0 and bc_services.sale_price <= ? ) OR (IFNULL(bc_services.sale_price,0) <= 0 and bc_services.price <= ? ) )";
            $model_service->WhereRaw($raw_sql_min_max, [
                $pri_from,
                $pri_from,
                $pri_to,
                $pri_to
            ]);
        }
        $review_scores = $request->query('review_score');
        if (is_array($review_scores) && !empty($review_scores)) {
            $where_review_score = [];
            $params = [];
            foreach ($review_scores as $number) {
                $where_review_score[] = " ( bc_services.review_score >= ? AND bc_services.review_score <= ? ) ";
                $params[] = $number;
                $params[] = $number . '.9';
            }
            $sql_where_review_score = " ( " . implode("OR", $where_review_score) . " )  ";
            $model_service->WhereRaw($sql_where_review_score, $params);
        }
        if (!empty($service_name = $request->query("service_name"))) {
            if (setting_item('site_enable_multi_lang') && setting_item('site_locale') != app()->getLocale()) {
                $model_service->leftJoin('bc_service_translations', function ($join) {
                    $join->on('bc_services.id', '=', 'bc_service_translations.origin_id');
                });
                $model_service->where('bc_service_translations.title', 'LIKE', '%' . $service_name . '%');
            } else {
                $model_service->where('bc_services.title', 'LIKE', '%' . $service_name . '%');
            }
        }
        $orderby = $request->input("orderby");
        switch ($orderby) {
            case "price_low_high":
                $raw_sql = "CASE WHEN IFNULL( bc_services.sale_price, 0 ) > 0 THEN bc_services.sale_price ELSE bc_services.price END AS tmp_min_price";
                $model_service->selectRaw($raw_sql);
                $model_service->orderBy("tmp_min_price", "asc");
                break;
            case "price_high_low":
                $raw_sql = "CASE WHEN IFNULL( bc_services.sale_price, 0 ) > 0 THEN bc_services.sale_price ELSE bc_services.price END AS tmp_min_price";
                $model_service->selectRaw($raw_sql);
                $model_service->orderBy("tmp_min_price", "desc");
                break;
            case "rate_high_low":
                $model_service->orderBy("review_score", "desc");
                break;
            default:
                $model_service->orderBy("is_featured", "desc");
                $model_service->orderBy("id", "desc");
        }
        $model_service->groupBy("bc_services.id");
        if (!empty($request->query('limit'))) {
            $limit = $request->query('limit');
        } else {
            $limit = 9;
        }
        return $model_service->with(['translations'])->paginate($limit);
    }

    public function dataForApi($forSingle = false)
    {
        $service = $this->service;
        $data = $service->dataForApi();
        return $data;
    }

    public function service()
    {
        $all = get_bookable_services();
        if ($this->object_model and !empty($all[$this->object_model])) {
            return $this->hasOne($all[$this->object_model], 'id', 'object_id');
        }
        return null;
    }
}

